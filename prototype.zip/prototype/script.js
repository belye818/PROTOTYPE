(function () {
  var now = new Date();

  var TODAY = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate()
  );

  function iso(n) {
    var d = new Date(
      TODAY.getFullYear(),
      TODAY.getMonth(),
      TODAY.getDate() + n
    );

    return (
      d.getFullYear() +
      '-' +
      String(d.getMonth() + 1).padStart(2, '0') +
      '-' +
      String(d.getDate()).padStart(2, '0')
    );
  }

  function greeting() {
    var h = now.getHours();

    return h < 12
      ? 'Good morning'
      : h < 18
        ? 'Good afternoon'
        : 'Good evening';
  }

  var tasks = [
    {
      id: 1,
      title: 'Calculus Problem Set 5',
      course: 'MATH 201',
      due: iso(0),
      time: '17:00',
      pri: 'High',
      done: false
    },
    {
      id: 2,
      title: 'HCI Module 4 Application Activity',
      course: 'HCI 301',
      due: iso(1),
      time: '23:59',
      pri: 'High',
      done: false
    },
    {
      id: 3,
      title: 'Networking quiz review',
      course: 'CS 220',
      due: iso(3),
      time: '09:00',
      pri: 'Medium',
      done: false
    },
    {
      id: 4,
      title: 'Algorithms report: max/min analysis',
      course: 'CS 210',
      due: iso(6),
      time: '12:00',
      pri: 'Medium',
      done: false
    },
    {
      id: 5,
      title: 'Cybersecurity lab write-up',
      course: 'CS 330',
      due: iso(9),
      time: '18:00',
      pri: 'Low',
      done: false
    },
    {
      id: 6,
      title: 'Group report outline',
      course: 'CS 210',
      due: iso(-1),
      time: '20:00',
      pri: 'Low',
      done: true
    }
  ];

  var nextId = 7;
  var filter = 'All';
  var current = 'home';
  var ver = 'A';
  var pri = 'Medium';

  var order = ['home', 'list', 'add'];

  var MON = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];

  var DAY = [
    'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'
  ];

  var COURSES = [
    'MATH 201',
    'HCI 301',
    'CS 210',
    'CS 220',
    'CS 330'
  ];

  var $ = function (id) {
    return document.getElementById(id);
  };

  var phone = $('phone');

  function parse(iso) {
    var p = iso.split('-').map(Number);

    return new Date(
      p[0],
      p[1] - 1,
      p[2]
    );
  }

  function diff(t) {
    return Math.round(
      (parse(t.due) - TODAY) / 864e5
    );
  }

  function fmtDate(iso) {
    var d = parse(iso);

    return (
      DAY[d.getDay()] +
      ', ' +
      MON[d.getMonth()] +
      ' ' +
      d.getDate()
    );
  }

  function fmtTime(s) {
    var p = s.split(':').map(Number);

    return (
      ((p[0] + 11) % 12 + 1) +
      ':' +
      String(p[1]).padStart(2, '0') +
      ' ' +
      (p[0] >= 12 ? 'PM' : 'AM')
    );
  }

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;'
      }[c];
    });
  }

  function sorted() {
    return tasks.slice().sort(function (a, b) {
      return (
        a.due + a.time + a.id <
        b.due + b.time + b.id
      ) ? -1 : 1;
    });
  }

  function label(t) {
    var d = diff(t);

    if (t.done) {
      return ['Done', 'ok'];
    }

    if (d < 0) {
      return ['Overdue', 'danger'];
    }

    if (d === 0) {
      return ['Today ' + fmtTime(t.time), 'danger'];
    }

    if (d === 1) {
      return ['Tomorrow', 'warn'];
    }

    if (d <= 2) {
      return ['In ' + d + ' days', 'warn'];
    }

    return [fmtDate(t.due), ''];
  }

  var CHECK =
    '<svg width="14" height="14" viewBox="0 0 24 24" ' +
    'fill="none" stroke="currentColor" stroke-width="3.5" ' +
    'stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M5 12l5 5 9-10"/>' +
    '</svg>';

  function row(t) {
    var l = label(t);

    return (
      '<li class="task' +
      (t.done ? ' done' : '') +
      '">' +

      '<button class="check" data-toggle="' +
      t.id +
      '" aria-label="' +
      (t.done ? 'Mark not done: ' : 'Mark done: ') +
      esc(t.title) +
      '">' +

      CHECK +

      '</button>' +

      '<div>' +
      '<div class="t">' +
      esc(t.title) +
      '</div>' +

      '<div class="c">' +
      esc(t.course) +
      ' · ' +
      t.pri +
      ' priority' +
      '</div>' +
      '</div>' +

      '<span class="pill ' +
      l[1] +
      '">' +
      l[0] +
      '</span>' +

      '</li>'
    );
  }

  function renderHome() {
    var open = sorted().filter(function (t) {
      return !t.done;
    });

    var next = open[0];

    var today = open.filter(function (t) {
      return diff(t) === 0;
    }).length;

    var week = open.filter(function (t) {
      return diff(t) >= 0 && diff(t) <= 6;
    }).length;

    var html =
      '<div class="eyebrow">' +
      fmtDate(iso(0)) +
      '</div>' +

      '<h2>' +
      greeting() +
      '</h2>' +

      '<div class="tiles">' +

      '<div class="tile' +
      (today ? ' alert' : '') +
      '">' +

      '<b>' +
      today +
      '</b>' +

      '<span>Due today</span>' +
      '</div>' +

      '<div class="tile">' +
      '<b>' +
      week +
      '</b>' +

      '<span>Due this week</span>' +
      '</div>' +

      '</div>';

    if (next) {
      html +=
        '<div class="next">' +

        '<div class="eyebrow">Next up</div>' +

        '<h3>' +
        esc(next.title) +
        '</h3>' +

        '<p>' +
        esc(next.course) +
        ' · ' +
        fmtDate(next.due) +
        ', ' +
        fmtTime(next.time) +
        '</p>' +

        '<div class="row">' +

        '<span class="remind">' +
        'Reminder: 1 hour before' +
        '</span>' +

        '<button class="btn-light" data-toggle="' +
        next.id +
        '">Mark done</button>' +

        '</div>' +
        '</div>';
    } else {
      html +=
        '<div class="next">' +

        '<h3>All caught up</h3>' +

        '<p>' +
        'No open deadlines. Add a task to keep planning.' +
        '</p>' +

        '</div>';
    }

    var up = open.slice(next ? 1 : 0, 4);

    html +=
      '<div class="sec-head">' +

      '<h3>Coming up</h3>' +

      '<button class="link" data-go="list">' +
      'See all' +
      '</button>' +

      '</div>';

    html += up.length
      ? '<ul class="list">' +
        up.map(row).join('') +
        '</ul>'
      : '<div class="empty">Nothing else due.</div>';

    $('s-home').innerHTML = html;
  }

  function renderList() {
    var items = sorted().filter(function (t) {
      return (
        filter === 'All' ||
        (filter === 'Pending' ? !t.done : t.done)
      );
    });

    var html =
      '<div class="eyebrow">' +

      tasks.filter(function (t) {
        return !t.done;
      }).length +

      ' open · ' +

      tasks.filter(function (t) {
        return t.done;
      }).length +

      ' done</div>' +

      '<h2>Assignments</h2>' +

      '<button class="wide-add" data-go="add">' +
      '+ Add new task' +
      '</button>' +

      '<div class="chips">' +

      ['All', 'Pending', 'Done'].map(function (f) {
        return (
          '<button class="chip" data-filter="' +
          f +
          '" aria-pressed="' +
          (f === filter) +
          '">' +
          f +
          '</button>'
        );
      }).join('') +

      '</div>';

    html += items.length
      ? '<ul class="list">' +
        items.map(row).join('') +
        '</ul>'
      : '<div class="empty">No tasks in this view.</div>';

    $('s-list').innerHTML = html;
  }

  function renderAdd() {
    $('s-add').innerHTML =
      '<button class="back" data-go="list">' +
      '‹ Back' +
      '</button>' +

      '<h2>New task</h2>' +

      '<label for="f-title">Task name</label>' +

      '<input id="f-title" type="text" ' +
      'placeholder="e.g. Read Chapter 6" autocomplete="off">' +

      '<p class="err" id="err" role="alert"></p>' +

      '<label for="f-course">Course</label>' +

      '<select id="f-course">' +

      COURSES.map(function (c) {
        return '<option>' + c + '</option>';
      }).join('') +

      '</select>' +

      '<div class="two">' +

      '<div>' +

      '<label for="f-date">Due date</label>' +

      '<input id="f-date" type="date" value="' +
      iso(2) +
      '">' +

      '</div>' +

      '<div>' +

      '<label for="f-time">Due time</label>' +

      '<input id="f-time" type="time" value="17:00">' +

      '</div>' +

      '</div>' +

      '<div class="lbl">Priority</div>' +

      '<div class="seg" id="seg">' +

      ['Low', 'Medium', 'High'].map(function (p) {
        return (
          '<button type="button" data-pri="' +
          p +
          '" aria-pressed="' +
          (p === pri) +
          '">' +
          p +
          '</button>'
        );
      }).join('') +

      '</div>' +

      '<label for="f-remind">Remind me</label>' +

      '<select id="f-remind">' +
      '<option>1 hour before</option>' +
      '<option>1 day before</option>' +
      '<option>2 days before</option>' +
      '<option>No reminder</option>' +
      '</select>' +

      '<button class="save" id="save">Save task</button>' +

      '<button class="cancel" data-go="home">' +
      'Cancel' +
      '</button>';
  }

  

  

  function renderGuide() {
    var g = GUIDE[current];

    $('guide').innerHTML =
      '<h2>' +
      g.t +
      '</h2>' +

      '<p>' +
      g.p +
      '</p>' +

      '<ul>' +

      g.l.map(function (x) {
        return '<li>' + x + '</li>';
      }).join('') +

      '</ul>';
  }

  function show() {
    var i = order.indexOf(current);

    order.forEach(function (n, k) {
      var el = $('s-' + n);

      el.classList.toggle('active', k === i);

      el.dataset.pos =
        k < i ? 'left' : k > i ? 'right' : 'mid';
    });

    ['home', 'list'].forEach(function (n) {
      var b = $('n-' + n);

      if (n === current) {
        b.setAttribute('aria-current', 'page');
      } else {
        b.removeAttribute('aria-current');
      }
    });

    if (current === 'add') {
      $('n-add').setAttribute('aria-current', 'page');
    } else {
      $('n-add').removeAttribute('aria-current');
    }

    phone.dataset.screen = current;

    renderGuide();
  }

  function go(name) {
    current = name;

    if (name === 'add') {
      renderAdd();
    } else {
      renderHome();
      renderList();
    }

    show();

    $('s-' + name).scrollTop = 0;
  }

  function toast(msg) {
    var t = $('toast');

    t.textContent = msg;
    t.classList.add('show');

    setTimeout(function () {
      t.classList.remove('show');
    }, 1800);
  }

  function setVer(v) {
    ver = v;
    phone.dataset.ver = v;

    $('vA').setAttribute('aria-pressed', v === 'A');
    $('vB').setAttribute('aria-pressed', v === 'B');
  }

  document.addEventListener('click', function (e) {
    var el = e.target.closest(
      '[data-go],[data-toggle],[data-filter],[data-pri],#save,#vA,#vB'
    );

    if (!el) {
      return;
    }

    if (el.id === 'vA') {
      return setVer('A');
    }

    if (el.id === 'vB') {
      return setVer('B');
    }

    if (el.dataset.go) {
      return go(el.dataset.go);
    }

    if (el.dataset.toggle) {
      var t = tasks.filter(function (x) {
        return x.id === Number(el.dataset.toggle);
      })[0];

      t.done = !t.done;

      renderHome();
      renderList();

      return toast(
        t.done
          ? 'Marked done'
          : 'Moved back to pending'
      );
    }

    if (el.dataset.filter) {
      filter = el.dataset.filter;

      return renderList();
    }

    if (el.dataset.pri) {
      pri = el.dataset.pri;

      Array.prototype.forEach.call(
        $('seg').children,
        function (b) {
          b.setAttribute(
            'aria-pressed',
            b.dataset.pri === pri
          );
        }
      );

      return;
    }

    if (el.id === 'save') {
      var title = $('f-title').value.trim();

      if (!title) {
        $('err').textContent =
          'Enter a task name to save.';

        $('f-title').focus();

        return;
      }

      var date = $('f-date').value || iso(2);

      tasks.push({
        id: nextId++,
        title: title,
        course: $('f-course').value,
        due: date,
        time: $('f-time').value || '17:00',
        pri: pri,
        done: false
      });

      pri = 'Medium';
      filter = 'All';

      go('list');

      toast('Task added');
    }
  });

  var hh = now.getHours() % 12 || 12;

  $('clock').textContent =
    hh +
    ':' +
    String(now.getMinutes()).padStart(2, '0');

  renderHome();
  renderList();
  renderAdd();
  show();
})();